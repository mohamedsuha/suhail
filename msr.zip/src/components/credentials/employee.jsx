import {useEffect, useState} from 'react';
import React, { useRef } from "react";
import ReactDOM from 'react-dom'
import 'bootstrap/dist/css/bootstrap.css';
import { getEmployee} from "../../service/credentials/employee.service"
import { activeEmployee } from '../../service/credentials/employee.service';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
function Employee() {
    const [lists,setLists] = useState([]);
    const [name,setName] = useState([]);
  const form = useRef();
  const navigate = useNavigate();
  const fileSubmitHandler = (event) => {
    event.preventDefault();
    console.log(name);
    navigate('/search/'+name);

  }
    useEffect(() => {
        (async () => {
          try {
            const result = await axios.get(
    "http://localhost:8080/lists")
            console.log(result.data);
            setLists(result.data)
          } catch (error) {
            console.error(error);
          }
        })()
      })
      const activeEmp= (id) => {
        navigate('/active/'+id);
        window.location.reload();
      }
const listItems = lists.map((list) =>
<tr>
<td>{list.name}</td>
<td>{list.dob}</td>
<td>{list.email}</td>
<td>{list.phone}</td>
<td>{list.hub}</td>
<td>{list.status}</td>
<td><span className='btn btn-info text-white'>Active</span></td>
</tr>
);
  return (
    <div className="App">
<div class="container mt-5">
<h1 className='text-center mb-3 text-primary'>Employee List</h1>
<div className="row justify-content-center">
  <div className="col-md-4">
<form onSubmit={fileSubmitHandler}>
  <div class="form-group float-left">
    <input required onChange={(event) => setName(event.target.value)}
     type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Search Employee" />
  </div>
  <span><button type="submit" class=" mt-3 btn btn-info text-white">Search</button></span>
  </form>
  </div>
  <div className="col-md-6"></div>
</div>
<div class="row justify-content-center">
  
<div className="col-md-10">

<table class="table">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Dob</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Hub</th>
      <th scope="col">Status</th>
      <th scope='col'>Operation</th>
    </tr>
  </thead>
  <tbody>
{
                lists.map((list) => { 
                    if (list.status === 'done') {
                        return <tr> <td>{list.name}</td>
                    <td>{list.dob}</td>
                    <td>{list.email}</td>
                    <td>{list.phone}</td>
                    <td>{list.hub}</td>
                    <td>{list.status}</td>
                    <td><a href="#"  ><span className='btn btn-success text-white'>Done</span></a></td>
                    </tr>;
                    }
                    return <tr> <td>{list.name}</td>
                    <td>{list.dob}</td>
                    <td>{list.email}</td>
                    <td>{list.phone}</td>
                    <td>{list.hub}</td>
                    <td>{list.status}</td>
                    <td><a href=""onClick={() => { activeEmp(list.id) }}><span className='btn btn-danger text-white'>Active</span></a></td>
                    </tr>
}

)
            }
  </tbody>
</table>
</div>
</div></div>
</div>
);
}
export default Employee;