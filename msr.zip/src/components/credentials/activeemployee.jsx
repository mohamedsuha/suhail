import {useEffect, useState} from 'react';
import React, { useRef } from "react";
import { useParams, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import axios from 'axios';
import Select from 'react-select';
import {addEmployee} from "../../service/credentials/register.service"
function Active() {
  const navigate = useNavigate();
  const [name,setName] = useState([]);
  const [dob,setDob] = useState([]);
  const [phone,setPhone] = useState([]);
  const [email,setEmail] = useState([]);
  const [hub,setHub] = useState([]);
  const [status,setStatus] = useState([]);
  const [fets,setFets] = useState([]);
  
  const [selectedValue, setSelectedValue] = useState(0);
    let { id } = useParams();
    console.log(id);
    const data = [
      {
        value: 1,
        label: "CCT"
      },
      {
        value: 2,
        label: "Bank"
      }
    ];
   // handle onChange event of the dropdown
  const handleChange = e => {
    setSelectedValue(e.label);
  }

    useEffect(() => {
      (async () => {
        try {
          const result = await axios.get(
  "http://localhost:8080/searchemp/"+id)
          console.log(result.data);
          setFets(result.data)
          setName(result.data.name);
          setEmail(result.data.email);
          setDob(result.data.dob);
          setPhone(result.data.phone)
          console.log(fets.name)
        } catch (error) {
          console.error(error);
        }
      })()
    }, []);
    const fileSubmitHandler = (event) => {
    event.preventDefault();
    console.log(selectedValue)
    if(selectedValue==0){
      alert('please select hub')
    }
    if(selectedValue!=0){
    let data= {
      hub:selectedValue,
      name:name,
      email:email,
      phone:phone,
      status:'done',
      dob:dob
    }
      axios.put('http://localhost:8080/update/'+id, data,  {headers: {
      'Content-Type': 'application/json'}
      });
      alert('Hub Updated Successfully');
      navigate('/admin');
    }
    }
  return (
    <div className="App register py-5">
      <div className="container">
        <div className="row">
          <div className="col-md-4 bg-light p-4">
          <form onSubmit={fileSubmitHandler}>
  <div class="form-group">
    <label for="exampleInputEmail1">User Name</label>
    <input required value={name}
     type="text" class="form-control" onChange={(event) => setName(event.target.value)}   id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Email</label>
    <input type="text" class="form-control" value={email} onChange={(event) => setEmail(event.target.value)}   name='email' id="exampleInputPassword1" placeholder="Email" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">DateOfBirth</label>
    <input type="date" class="form-control" value={dob} onChange={(event) => setDob(event.target.value)}  name='dob' id="exampleInputPassword1" placeholder="DateOfBirth" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Phone</label>
    <input type="number" class="form-control"value={phone} name='phone' onChange={(event) => setPhone(event.target.value)}   id="exampleInputPassword1" placeholder="phone" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Hub</label>
    <Select
        placeholder="Select Option"
        value={data.find(obj => obj.value === selectedValue)} 
        options={data} 
        onChange={handleChange} 
      />
  
  </div>
  <button type="submit" class=" mt-3 btn btn-primary">Active</button>
  <button type="cancel" onClick={()=>navigate("/admin")} class=" mt-3 btn btn-danger mx-3">Cancel</button>
</form>
          </div>
        </div>
      </div>
</div>
  );
  
}

export default Active;