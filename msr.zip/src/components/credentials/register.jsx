import {useEffect, useState} from 'react';
import React, { useRef } from "react";
import 'bootstrap/dist/css/bootstrap.css';
import {addEmployee} from "../../service/credentials/register.service"
function Register() {
    const form = useRef();
    const fileSubmitHandler = (event) => {
    event.preventDefault();
    let newemployee = {
        name:form.current.name.value,
        phone:form.current.phone.value,
        email:form.current.email.value,
        dob:form.current.dob.value,
        status:'pending'
    }
    console.log(newemployee);
    addEmployee(newemployee);
    }
  return (
    <div className="App register py-5">
      <div className="container">
        <div className="row">
          <div className="col-md-4 bg-light p-4">
          <form ref={form} onSubmit={fileSubmitHandler}>
  <div class="form-group">
    <label for="exampleInputEmail1">User Name</label>
    <input required
     type="text" class="form-control" name='name' id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Username" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Email</label>
    <input type="text" class="form-control" name='email' id="exampleInputPassword1" placeholder="Email" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">DateOfBirth</label>
    <input type="date" class="form-control" name='dob' id="exampleInputPassword1" placeholder="DateOfBirth" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Phone</label>
    <input type="number" class="form-control" name='phone' id="exampleInputPassword1" placeholder="phone" />
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
          </div>
        </div>
      </div>
      
</div>
  );
  
}

export default Register;