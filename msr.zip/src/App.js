import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import React, { useRef } from 'react';
import { BrowserRouter,useNavigate, Routes, Route } from "react-router-dom";
import Register from './components/credentials/register';
import Employee from './components/credentials/employee';
import Active from './components/credentials/activeemployee';
import Search from './components/credentials/search';
function App() {
    const navigate = useNavigate();
  return (
   <div className='App'>
     <header>
        <nav class="navbar navbar-expand-sm ">
            <div class="container-fluid">
              <a class="navbar-brand " href="#">MSR Portal</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                <ul class="navbar-nav ">
                  <li class="nav-item">
                    <a class="nav-link" href='#' onClick={()=>navigate("/register")} >Register</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href='#' >Login</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                  </li>			
                  <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#" onClick={()=>navigate("/admin")}>Admin</a>
                  </li>
                </ul>		  
              </div>
            </div>
          </nav>
    </header>
    <Routes>
   <Route path = '/register' element = {<Register/>}></Route>
   <Route path = '/admin' element = {<Employee/>}></Route>
   <Route path = '/active/:id' element = {<Active/>}></Route>
   <Route path = '/search/:name' element = {<Search/>}></Route>
  </Routes>
  
   </div>
  );
}

export default App;
