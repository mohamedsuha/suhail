import axios from "axios";
import ReactDOM from 'react-dom'
import React from "react";
import { useNavigate } from "react-router-dom";
export const getEmployee= async () => {
 return await axios.get("http://localhost:8080/lists")
}
export const activeEmployee= (id) => {
    axios.get('http://localhost:8080/active/'+id);
    alert("Employee active successfully")
  }