import axios from "axios";
import ReactDOM from 'react-dom'
import React from "react";
export const addEmployee= (data) => {
  var answer = JSON.stringify(data);
  axios.post('http://localhost:8080/add', answer,  {headers: {
  'Content-Type': 'application/json'}
  });
}