package com.example.msrportal.msr;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class EmployeeController {
private EmployeeRepository employeeRepository;

public EmployeeController(EmployeeRepository employeeRepository) {
	super();
	this.employeeRepository = employeeRepository;
}
@GetMapping(path = "/lists")
public  List<Employee>  getEmployee( Model model) {
	  return employeeRepository.findAll();
}
@RequestMapping(value="/add", method=RequestMethod.POST)
public String question(@RequestBody Employee employee,BindingResult result){
employeeRepository.save(employee);
    return "success";
}
@GetMapping("/search/{name}")
public List<Employee> showUpdateForm(@PathVariable("name") String name, Model model) {	   
	return employeeRepository.findByName(name);
}
@GetMapping("/searchemp/{id}")
public Employee showEmp(@PathVariable("id") int id, Model model) {	 
	 Employee Employee = employeeRepository.findById((long) id).orElseThrow(() -> new IllegalArgumentException("Invalid Product Id:" + id));
	return Employee;
}
@RequestMapping(value="/update/{id}", method=RequestMethod.PUT)
public String updateEmployee(@PathVariable("id") long id, Model model,@RequestBody Employee employee) {
	System.out.println(employee.getId());
	employee.setId(id);
	System.out.println(employee.getId());
	employeeRepository.save(employee);
	return "success";
}
@GetMapping("/delete/{id}")
public String deleteUser(@PathVariable("id") long id, Model model) {
    Employee Employee = employeeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid Product Id:" + id));
    employeeRepository.delete(Employee);
    return "success";
}
}