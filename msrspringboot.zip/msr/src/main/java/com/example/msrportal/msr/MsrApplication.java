package com.example.msrportal.msr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsrApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsrApplication.class, args);
	}

}
