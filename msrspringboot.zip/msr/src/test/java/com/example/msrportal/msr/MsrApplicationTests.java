package com.example.msrportal.msr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsrApplicationTests {

	@Test
	void contextLoads() {
	}

}
